# Captain Clove · Spelling Bee Challenge

A single-page browser game where players unscramble 5 random words against a 60-second clock. Built as a static HTML/CSS/JS site — no build step, no dependencies.

## Features

- 5 random words drawn from a pool of 13 each round
- 60-second total timer with warning/danger states
- One submission attempt per word, with an optional hint
- End-of-round scorecard with per-word review
- Persistent leaderboard (localStorage, shared via `window.storage` API when available)

## Run locally

It's a single HTML file — just open it:

```bash
open index.html        # macOS
xdg-open index.html    # Linux
start index.html       # Windows
```

Or serve it with any static server (recommended, since some browsers restrict storage on `file://`):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Project structure

```
.
├── index.html       # The whole game — HTML, CSS, and JS inline
├── assets/
│   └── dabur-logo.png   # Logo shown in the top-left (add your own)
├── README.md
├── LICENSE
└── .gitignore
```

## About the logo

The original artifact embedded the Dabur logo as a base64 string inside `index.html`. This repo references it as an external file at `assets/dabur-logo.png` instead, which keeps `index.html` readable. The `<img>` tag has an `onerror` handler that hides the logo if the file is missing, so the game still works without it.

To use a different logo, drop your image at `assets/dabur-logo.png` (or update the `src` attribute in `index.html`).

## Deploy to GitHub Pages

After pushing to GitHub:

1. Repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` / root → **Save**
4. Wait ~30 seconds, then visit `https://<your-username>.github.io/<repo-name>/`

## Push to GitHub

From this folder:

```bash
git init
git add .
git commit -m "Initial commit: Captain Clove Spelling Bee"
git branch -M main

# Create the repo on GitHub first (via web UI or `gh repo create`), then:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

If you have the GitHub CLI installed:

```bash
gh repo create captain-clove --public --source=. --remote=origin --push
```

## License

MIT — see [LICENSE](LICENSE).
